/*
Nom et prenom   :  Nguyen Thi Quynh Hoa
Code d'etudiant :  1752017
Classe          :  17VP
*/

public class Paiement {
    private double i_montant;
    private TypePaiement modeDePaiment;

    public void Operation(){

    }

    public double getI_montant() {
        return i_montant;
    }

    public void setI_montant(double i_montant) {
        this.i_montant = i_montant;
    }

    public TypePaiement getModeDePaiment() {
        return modeDePaiment;
    }

    public void setModeDePaiment(TypePaiement modeDePaiment) {
        this.modeDePaiment = modeDePaiment;
    }
}
