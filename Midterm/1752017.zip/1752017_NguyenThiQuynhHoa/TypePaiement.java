/*
Nom et prenom   :  Nguyen Thi Quynh Hoa
Code d'etudiant :  1752017
Classe          :  17VP
*/

public enum TypePaiement {
    CARTE_BANCAIRE,
    PORTE_MONNAIE,
    AUTRES_MODES
}
