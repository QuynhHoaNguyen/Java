/*
Nom et prenom   :  Nguyen Thi Quynh Hoa
Code d'etudiant :  1752017
Classe          :  17VP
*/

public class CommandeDetaillee {
    private int i_quantite;

    public void calSosTotal(){
        //Tinh tong so luong cua mot mat hang da mua
    }
    public void calPoids(){
        //Tinh tong trong luong cua mot mat hang da mua
    }


    public int getI_quantite() {
        return i_quantite;
    }

    public void setI_quantite(int i_quantite) {
        this.i_quantite = i_quantite;
    }
}
