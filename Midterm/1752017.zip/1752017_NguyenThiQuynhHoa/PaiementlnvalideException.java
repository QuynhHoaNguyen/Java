/*
Nom et prenom   :  Nguyen Thi Quynh Hoa
Code d'etudiant :  1752017
Classe          :  17VP
*/


public class PaiementlnvalideException {
    //xu ly cac ngoai le
}
