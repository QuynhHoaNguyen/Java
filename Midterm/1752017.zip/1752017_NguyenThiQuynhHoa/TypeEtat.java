/*
Nom et prenom   :  Nguyen Thi Quynh Hoa
Code d'etudiant :  1752017
Classe          :  17VP
*/

public enum TypeEtat {
    ENREGISTRE,
    RECEPTIONNE,
    ACCEPTE,
    REFUSE,
    ENVOYE
}
