public enum TypePaiement {
	CARTE_BANCAIRE,
	PORTE_MONNAIE,
	AUTRES_MODES
}
